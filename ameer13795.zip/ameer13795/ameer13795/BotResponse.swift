//
//  BotResponse.swift
//  Aichatbot
//
//  Created by Ameer Radhi on 29/05/2023.
//

import Foundation


struct BotResponse {
    func getBotResponse(message: String) -> [String] {
        let tempMessage = message.lowercased()
      print(tempMessage)
        if tempMessage.contains("what is an exoplanet") {
            return ["An exoplanet is a planet which resembles earth in terms of size, its distance from the star, atmosphere and gravity alongside other factors. Most exoplanets are in the habitable zone of its own star."]
        } else if tempMessage.contains("what is the nearest exoplanet") {
            return ["The closest known exoplanet is called Proxima Centauri b and it is about 4 light years away meaning it would take 4 years traveling at the speed of light to reach it."]
        } else if tempMessage.contains("tell me about the exoplanet kepler 22b") {
            return ["Kepler 22b is a exoplanet that is in the habitable zone of its own star(Kepler 22). It is located 640 light years away from earth in the constellation of Cygnus.", "Kepler 22b"]
        } else if tempMessage.contains("tell me about the exoplanet gliese 667cc") {
            return ["Gliese 667Cc is a exoplanet located in the constellation of scorpius around 23.62 light years away. It is also orbiting a triple star system meaning you could see three stars in its skies, one of those stars being Gliese 667C.", "Gliese_667_Cf"]
        } else if tempMessage.contains("tell me about the exoplanet kepler 62f") {
            return ["Kepler 62f is a super-earth that is located around 980 light years away in the constellation of Lyra. Based on its size which is 1.42 the size of earth, Kepler 62f is believed to be an ocean filled planet.", "kepler62f"]
        } else if tempMessage.contains("tell me about the exoplanet kepler 186f") {
            return ["Kepler 186f is the first exoplanet discovered that had a similar radius that of the earth located in the habitable zone of its star. It is about 580 light years away from earth.", "kepler186f"]
        } else if tempMessage.contains("what is the reason for exoplanets to be discovered") {
            return ["Scientists around the world have always asked the question that if there is life outside of earth and if life can be capable on other planets. The discovery of exoplanets gave scientists an idea with a glimpse of hope that there would be a planet capable of sustaining human life but due to our technology not being at its fullest its still a blue wether life does exist other than earth or not."]
        } else if tempMessage.contains("how is an exoplanet discovered") {
            return ["One way which an exoplanet is discovered is called the transit method. This method is when a planet passes by its star which causes a dim in the brightness of the star and from that telescopes can measure the radius of the planet."]
        } else if tempMessage.contains("what is the biggest exoplanet") {
            return ["Hat-p-67 is a massive gas giant twice the diameter of Jupiter. Though the planet orbits its star so closely its years only last 5 earth days. Due to this planet being so close to its star, it is slowly getting destroyed as its star expands in size", "HATP67b"]
        } else if tempMessage.contains("what exoplanet is most likely to sustain life") {
            return ["Kepler 283c is just of 7 exoplanets discovered which NASA says could potentially host life."]
        } else {
            return ["That's cool"]
        }
    }
}
