//
//  model.swift
//  ameer13795
//
//  Created by Timothy Head on 05/06/2023.
//

import Foundation

struct Model: Hashable {
    var image: String?
    var answer: String
}
