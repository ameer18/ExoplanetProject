//
//  ChatBubbleView.swift
//  ameer13795
//
//  Created by Timothy Head on 02/06/2023.
//

import SwiftUI

struct ChatBubbleView: View {
    var message: Model
    var isUserMessage: Bool
   
    
    
    
    var body: some View {
        HStack {
            if isUserMessage {
              
                VStack {
                    Text(message.answer)
                        .padding()
                        .foregroundColor(.white)
                      .background(Color.blue.opacity(0.9))
                        .cornerRadius(10)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 10)
                   
                }
            } else {
                VStack {
                 
                    Text(message.answer)
                        .padding()
                        .background(Color.gray.opacity(0.15))
                        .cornerRadius(10)
                        .padding(.horizontal, 16)
                        .padding(.bottom, 10)
               
                        if  !isUserMessage {
                          
                            if !message.image!.isEmpty {
                                Image(uiImage: (UIImage(named: message.image ?? "") ?? UIImage()))
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: UIScreen.main.bounds.width - 40)
                            }
                        }
                   
                       
                 
                }
            }
        }
        
    }
}

struct ChatBubbleView_Previews: PreviewProvider {
    static var previews: some View {
        ChatBubbleView(message: Model(image: "kepler62f", answer: "Hello asdfghjhgfcxzxcvbhnjkjhgfdsxdfghjhgfdfghjkjhgfdfghjkjhgvcvbnmnbvcvbnmnbvcvbnmnbvcvbnmjhgfghjkjhgfghjk"), isUserMessage: false)
    }
}
