import SwiftUI



struct ContentView: View {
    @State private var messageText = ""
    @State private var messages: [Model] = [Model(image: "", answer: "Welcome to the ExoplanetAI")]
    let botResponse = BotResponse()
    @State private var image = [String]()
    var model = Model(image: "", answer: "")
    
    var body: some View {
        VStack {
            HStack {
                Text("ExoplanetBot")
                    .font(.largeTitle)
                    .bold()
                
                Image(systemName: "bubble.left.fill")
                    .font(.system(size: 29))
                    .foregroundColor(.red)
              
            }
            

            Scroll(messages: messages)
            
            HStack {
                TextField("Type here", text: $messageText)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .onSubmit {
                        sendMessage(message: messageText)
                    }
                
                Button(action: {
                    sendMessage(message: messageText)
                }) {
                    Image(systemName: "paperplane.fill")
                }
                .font(.system(size: 26))
                .padding(.horizontal, 10)
            }
            .padding()
        }
    }
    
    private func sendMessage(message: String) {
        withAnimation {
            messages.append(Model(image: "", answer: "[USER]" + message))
            self.messageText = ""
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            withAnimation {
                let response = botResponse.getBotResponse(message: message)
               
                messages.append(Model(image: response.count > 1 ? response[1] : "", answer: response[0]))
              
            }
        }
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

