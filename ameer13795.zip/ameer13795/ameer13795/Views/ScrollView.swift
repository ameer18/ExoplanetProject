//
//  ScrollView.swift
//  ameer13795
//
//  Created by Timothy Head on 02/06/2023.
//

import SwiftUI

struct Scroll: View {
    
    var messages: [Model]
   
    
    var body: some View {
        ScrollView {
       
               
                VStack(alignment: .leading) {
                    ForEach(messages, id: \.self) { message in
                        ChatBubbleView(message: message, isUserMessage: message.answer.contains("[USER]"))
                    }
                }
               
            
                
           
        }
       
    }
}

struct Scroll_Previews: PreviewProvider {
    static var previews: some View {
        Scroll(messages: [Model(image: "kepler62f", answer: "hello")])
    }
}
