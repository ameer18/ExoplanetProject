//
//  ameer13795App.swift
//  ameer13795
//
//  Created by Timothy Head on 02/06/2023.
//

import SwiftUI

@main
struct ameer13795App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
