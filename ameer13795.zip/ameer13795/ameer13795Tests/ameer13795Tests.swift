//
//  ameer13795Tests.swift
//  ameer13795Tests
//
//  Created by Timothy Head on 02/06/2023.
//

import XCTest
@testable import ameer13795

final class ameer13795Tests: XCTestCase {
  var bot: BotResponse!

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        bot = BotResponse()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        bot  = nil
    }

    func testAnswers1() {
  
        XCTAssertEqual("An exoplanet is a planet which resembles earth in terms of size, its distance from the star, atmosphere and gravity alongside other factors. Most exoplanets are in the habitable zone of its own star.",  bot.getBotResponse(message: " What is an exoplanet"))
    }
    func testAnswers2() {
        XCTAssertEqual("The closest known exoplanet is called Proxima Centauri b and it is about 4 light years away meaning it would take 4 years traveling at the speed of light to reach it.", bot.getBotResponse(message: "what is the nearest exoplanet"))
    }
    func testAnswers3() {
        XCTAssertEqual("Kepler 22b is a exoplanet that is in the habitable zone of its own star(Kepler 22). It is located 640 light years away from earth in the constellation of Cygnus.", bot.getBotResponse(message: "tell me about the exoplanet kepler 22b"))
    }
    func testAnswers4() {
        XCTAssertEqual("Gliese 667Cc is a exoplanet located in the constellation of scorpius around 23.62 light years away. It is also orbiting a triple star system meaning you could see three stars in its skies, one of those stars being Gliese 667C.", bot.getBotResponse(message: "Gliese 667Cc"))
    }
    func testAnswers5() {
        XCTAssertEqual("Kepler 62f is a super-earth that is located around 980 light years away in the constellation of Lyra. Based on its size which is 1.42 the size of earth, Kepler 62f is believed to be an ocean filled planet.", bot.getBotResponse(message: "tell me about the exoplanet Kepler 62f"))
    }
    func testAnswers6() {
        XCTAssertEqual("Kepler 186f is the first exoplanet discovered that had a similar radius that of the earth located in the habitable zone of its star. It is about 580 light years away from earth.", bot.getBotResponse(message: "Tell me about the exoplanet Kepler 186f"))
    }
    func testAnswers7() {
        XCTAssertEqual("Scientists around the world have always asked the question that if there is life outside of earth and if life can be capable on other planets. The discovery of exoplanets gave scientists an idea with a glimpse of hope that there would be a planet capable of sustaining human life but due to our technology not being at its fullest its still a blue wether life does exist other than earth or not.", bot.getBotResponse(message: "what is the reason for exoplanets to be discovered"))
    }
    func testAnswers8() {
        XCTAssertEqual("One way which an exoplanet is discovered is called the transit method. This method is when a planet passes by its star which causes a dim in the brightness of the star and from that telescopes can measure the radius of the planet.", bot.getBotResponse(message: "How is an exoplanet discovered"))
    }
    func testAnswers9() {
        XCTAssertEqual("Hat-p-67 is a massive gas giant twice the diameter of Jupiter. Though the planet orbits its star so closely its years only last 5 earth days.", bot.getBotResponse(message: "What is the biggest exoplanet"))
    }
    func testAnswers10() {
        XCTAssertEqual("Kepler 283c is just of 7 exoplanets discovered which NASA says could potentially host life.", bot.getBotResponse(message: "What exoplanet is most likely to sustain life"))
    }



    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }

}
